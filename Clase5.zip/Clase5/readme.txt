Basado en https://github.com/tuzzer/gym-maze
Dependencias:
 - pip install pygame gym
